[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
# discotimes
Automated estimation of trends, discontinuities and nonlinearities in vertical land motion using Bayesian Inference. Framework to detecting change points in GNSS, 'altimetry minus tide gauge' and other geophysical time series.
